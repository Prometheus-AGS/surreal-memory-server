//! Protocol-version negotiation matrix for the MCP server, across both
//! transports the binary exposes: stdio and streamable HTTP.
//!
//! Written for the rmcp 1.4.0 -> 3.4.0 upgrade. Root cause of the reported
//! initialization failures: rmcp 1.4.0 predates 2025-11-25 support (added in
//! 1.5.0) and predates the 2026-07-28 discover/per-request-meta lifecycle
//! (added in 3.0.0-beta.1's SEP-2575 work), so any client negotiating either
//! revision was rejected outright. `MemoryMcpServer` does not override
//! `ServerHandler::supported_protocol_versions`'s SDK default beyond
//! re-stating it explicitly (see `src/mcp/mod.rs`), so upgrading the crate is
//! what actually fixes this; these tests are the evidence.
//!
//! Both transports are driven with hand-rolled, newline-delimited or SSE-wire
//! JSON-RPC — deliberately NOT rmcp's own client machinery — because the
//! actual client population (Claude Desktop, Cursor, and friends) does not
//! link `rmcp` either. A server that only satisfies its own SDK's client
//! would prove nothing about interop.
//!
//! Storage is `SurrealStorage::new_mem` (embedded, in-memory) with a
//! deterministic no-op embedder: no network call, no shared `:28000`
//! instance, per `docs/lessons.md`. Every test gets its own fresh server and
//! storage instance.

use std::sync::Arc;
use std::time::Duration;

use axum::Router;
use reqwest::{
    Client,
    header::{HeaderMap, HeaderName, HeaderValue},
};
use serde_json::{Value, json};
use surreal_memory::{EmbeddingService, MemoryStorage, SurrealStorage};
use surreal_memory_server::mcp::{MemoryMcpServer, http::mcp_http_router};
use tokio::io::{AsyncBufReadExt, AsyncWriteExt, BufReader, DuplexStream, ReadHalf, WriteHalf};

/// Every MCP protocol revision this server must negotiate. Mirrors
/// `rmcp::model::ProtocolVersion::KNOWN_VERSIONS` as literal strings so a
/// mismatch here (e.g. the SDK adding/removing a version) shows up as an
/// explicit test failure instead of silently changing what "the matrix"
/// means.
const ALL_VERSIONS: [&str; 5] = [
    "2024-11-05",
    "2025-03-26",
    "2025-06-18",
    "2025-11-25",
    "2026-07-28",
];

/// `grep -c '#\[tool(' src/mcp/mod.rs`, unchanged by the rmcp 1.4.0 -> 3.4.0
/// upgrade (which only touched `ServerConfig`/`ContentBlock`/
/// `ProgressNotificationParam` type usage, not the tool set).
const EXPECTED_TOOL_COUNT: usize = 59;

struct NoOpEmbedder;

#[async_trait::async_trait]
impl EmbeddingService for NoOpEmbedder {
    async fn embed(&self, _text: &str) -> anyhow::Result<Vec<f32>> {
        Ok(vec![0.0; 1536])
    }

    async fn embed_batch(&self, texts: Vec<String>) -> anyhow::Result<Vec<Vec<f32>>> {
        Ok(texts.into_iter().map(|_| vec![0.0; 1536]).collect())
    }

    fn dimensions(&self) -> usize {
        1536
    }
}

async fn isolated_storage() -> Arc<dyn MemoryStorage> {
    let embedder: Arc<dyn EmbeddingService> = Arc::new(NoOpEmbedder);
    Arc::new(
        SurrealStorage::new_mem(embedder)
            .await
            .expect("isolated in-memory embedded SurrealStorage"),
    )
}

// ─────────────────────────────────────────────────────────────────────────
// stdio-shaped transport: an in-process duplex pipe running the real
// `MemoryMcpServer` over rmcp's actual newline-delimited JSON-RPC codec (the
// same one `rmcp::transport::stdio()` uses over real stdin/stdout).
// ─────────────────────────────────────────────────────────────────────────

async fn spawn_stdio_server() -> (BufReader<ReadHalf<DuplexStream>>, WriteHalf<DuplexStream>) {
    let storage = isolated_storage().await;
    let server = MemoryMcpServer::new(storage);
    let (client_side, server_side) = tokio::io::duplex(1 << 20);
    let running = rmcp::ServiceExt::serve(server, server_side)
        .await
        .expect("serve the real MemoryMcpServer over an in-process duplex transport");
    tokio::spawn(async move {
        let _ = running.waiting().await;
    });
    let (read_half, write_half) = tokio::io::split(client_side);
    (BufReader::new(read_half), write_half)
}

async fn send_line(write: &mut WriteHalf<DuplexStream>, message: &Value) {
    let mut line = serde_json::to_vec(message).expect("serialize JSON-RPC message");
    line.push(b'\n');
    write.write_all(&line).await.expect("write JSON-RPC line");
}

async fn recv_line(read: &mut BufReader<ReadHalf<DuplexStream>>) -> Value {
    let mut line = String::new();
    tokio::time::timeout(Duration::from_secs(5), read.read_line(&mut line))
        .await
        .expect("a JSON-RPC line arrives within 5s")
        .expect("read JSON-RPC line");
    serde_json::from_str(line.trim_end())
        .unwrap_or_else(|error| panic!("expected a JSON-RPC line, got {line:?}: {error}"))
}

fn assert_successful_call(response: &Value) {
    assert!(
        response.get("error").is_none(),
        "tools/call returned a JSON-RPC error: {response:?}"
    );
    assert_ne!(
        response["result"]["isError"].as_bool().unwrap_or(false),
        true,
        "read_graph tool call reported isError: {response:?}"
    );
}

fn assert_tool_count(list_response: &Value) {
    let tools = list_response["result"]["tools"]
        .as_array()
        .unwrap_or_else(|| panic!("tools/list result missing a tools array: {list_response:?}"));
    assert_eq!(
        tools.len(),
        EXPECTED_TOOL_COUNT,
        "tool count changed across the rmcp upgrade: {list_response:?}"
    );
}

/// Drive one protocol version end to end over the stdio-shaped transport.
///
/// Legacy versions (`< 2026-07-28`) use the `initialize` handshake.
/// `2026-07-28` replaced that handshake with `server/discover` plus
/// per-request `_meta` (SEP-2575); it never calls `initialize`.
async fn run_stdio_version_case(version: &str) {
    let (mut read, mut write) = spawn_stdio_server().await;

    if version == "2026-07-28" {
        send_line(
            &mut write,
            &json!({"jsonrpc": "2.0", "id": 1, "method": "server/discover", "params": {}}),
        )
        .await;
        let discover = recv_line(&mut read).await;
        let supported: Vec<String> = discover["result"]["supportedVersions"]
            .as_array()
            .unwrap_or_else(|| panic!("server/discover missing supportedVersions: {discover:?}"))
            .iter()
            .map(|v| v.as_str().unwrap_or_default().to_string())
            .collect();
        for known in ALL_VERSIONS {
            assert!(
                supported.iter().any(|v| v == known),
                "server/discover must advertise {known}, got {supported:?}"
            );
        }

        let meta = json!({
            "io.modelcontextprotocol/protocolVersion": version,
            "io.modelcontextprotocol/clientCapabilities": {}
        });

        send_line(
            &mut write,
            &json!({
                "jsonrpc": "2.0", "id": 2, "method": "tools/list",
                "params": {"_meta": meta}
            }),
        )
        .await;
        assert_tool_count(&recv_line(&mut read).await);

        send_line(
            &mut write,
            &json!({
                "jsonrpc": "2.0", "id": 3, "method": "tools/call",
                "params": {"name": "read_graph", "arguments": {}, "_meta": meta}
            }),
        )
        .await;
        assert_successful_call(&recv_line(&mut read).await);
    } else {
        send_line(
            &mut write,
            &json!({
                "jsonrpc": "2.0", "id": 1, "method": "initialize",
                "params": {
                    "protocolVersion": version,
                    "capabilities": {},
                    "clientInfo": {"name": "protocol-matrix-test", "version": "0.0.0"}
                }
            }),
        )
        .await;
        let initialize = recv_line(&mut read).await;
        assert_eq!(
            initialize["result"]["protocolVersion"], version,
            "server did not echo the requested legacy protocol version: {initialize:?}"
        );

        send_line(
            &mut write,
            &json!({"jsonrpc": "2.0", "method": "notifications/initialized"}),
        )
        .await;

        send_line(
            &mut write,
            &json!({"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}}),
        )
        .await;
        assert_tool_count(&recv_line(&mut read).await);

        send_line(
            &mut write,
            &json!({
                "jsonrpc": "2.0", "id": 3, "method": "tools/call",
                "params": {"name": "read_graph", "arguments": {}}
            }),
        )
        .await;
        assert_successful_call(&recv_line(&mut read).await);
    }
}

#[tokio::test]
async fn stdio_protocol_version_2024_11_05() {
    run_stdio_version_case("2024-11-05").await;
}

#[tokio::test]
async fn stdio_protocol_version_2025_03_26() {
    run_stdio_version_case("2025-03-26").await;
}

#[tokio::test]
async fn stdio_protocol_version_2025_06_18() {
    run_stdio_version_case("2025-06-18").await;
}

#[tokio::test]
async fn stdio_protocol_version_2025_11_25() {
    run_stdio_version_case("2025-11-25").await;
}

#[tokio::test]
async fn stdio_protocol_version_2026_07_28_uses_discover_and_per_request_meta() {
    run_stdio_version_case("2026-07-28").await;
}

// ─────────────────────────────────────────────────────────────────────────
// Streamable HTTP transport: a real axum server bound to 127.0.0.1:0,
// serving the actual production router (`mcp::http::mcp_http_router`, the
// same one `src/api/mod.rs` mounts at `/mcp`).
//
// The server's default `StreamableHttpServerConfig` (`legacy_session_mode:
// true, json_response: false`) means every successful response — for every
// protocol version, including 2026-07-28's per-request-negotiated calls —
// comes back as a `text/event-stream` body with the JSON-RPC message on a
// `data:` line. `read_sse_json_rpc` below is the one parser both legacy and
// 2026-07-28 flows share.
// ─────────────────────────────────────────────────────────────────────────

async fn spawn_http_server() -> String {
    let storage = isolated_storage().await;
    let router: Router = mcp_http_router(storage, "/mcp");
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0")
        .await
        .expect("bind an ephemeral loopback port");
    let addr = listener.local_addr().expect("listener local addr");
    tokio::spawn(async move {
        let _ = axum::serve(listener, router).await;
    });
    format!("http://{addr}/mcp/http")
}

struct HttpRpcResponse {
    status: reqwest::StatusCode,
    session_id: Option<String>,
    body: Option<Value>,
    raw_text: String,
}

fn json_headers(session_id: Option<&str>, protocol_version_header: Option<&str>) -> HeaderMap {
    let mut headers = HeaderMap::new();
    headers.insert(
        reqwest::header::CONTENT_TYPE,
        HeaderValue::from_static("application/json"),
    );
    headers.insert(
        reqwest::header::ACCEPT,
        HeaderValue::from_static("application/json, text/event-stream"),
    );
    if let Some(session_id) = session_id {
        headers.insert(
            HeaderName::from_static("mcp-session-id"),
            HeaderValue::from_str(session_id).expect("session id is a valid header value"),
        );
    }
    if let Some(version) = protocol_version_header {
        headers.insert(
            HeaderName::from_static("mcp-protocol-version"),
            HeaderValue::from_str(version).expect("protocol version is a valid header value"),
        );
    }
    headers
}

/// POST one JSON-RPC message and read back either an SSE-framed response
/// (the production default) or a plain body (error responses, and 202
/// Accepted for notifications).
async fn post_json_rpc(client: &Client, url: &str, headers: HeaderMap, body: Value) -> HttpRpcResponse {
    let response = tokio::time::timeout(
        Duration::from_secs(10),
        client.post(url).headers(headers).json(&body).send(),
    )
    .await
    .expect("HTTP response headers arrive within 10s")
    .expect("POST request succeeds at the transport level");
    let status = response.status();
    let session_id = response
        .headers()
        .get("mcp-session-id")
        .and_then(|v| v.to_str().ok())
        .map(str::to_string);
    let content_type = response
        .headers()
        .get(reqwest::header::CONTENT_TYPE)
        .and_then(|v| v.to_str().ok())
        .unwrap_or_default()
        .to_string();
    let raw_text = tokio::time::timeout(Duration::from_secs(10), response.text())
        .await
        .expect("HTTP response body completes within 10s (request-scoped SSE stream closes after its response)")
        .expect("read response body");
    let body = if content_type.starts_with("text/event-stream") {
        raw_text
            .lines()
            .filter_map(|line| line.strip_prefix("data:"))
            .map(str::trim)
            .find(|data| !data.is_empty())
            .and_then(|data| serde_json::from_str::<Value>(data).ok())
    } else if !raw_text.is_empty() {
        serde_json::from_str::<Value>(&raw_text).ok()
    } else {
        None
    };
    HttpRpcResponse {
        status,
        session_id,
        body,
        raw_text,
    }
}

/// Drive one protocol version end to end over streamable HTTP.
async fn run_http_version_case(version: &str) {
    let base = spawn_http_server().await;
    let client = Client::new();

    if version == "2026-07-28" {
        let discover = post_json_rpc(
            &client,
            &base,
            json_headers(None, None),
            json!({"jsonrpc": "2.0", "id": 1, "method": "server/discover", "params": {}}),
        )
        .await;
        assert_eq!(
            discover.status,
            reqwest::StatusCode::OK,
            "server/discover failed: {}",
            discover.raw_text
        );
        let discover_body = discover
            .body
            .unwrap_or_else(|| panic!("server/discover produced no JSON-RPC body: {}", discover.raw_text));
        let supported: Vec<String> = discover_body["result"]["supportedVersions"]
            .as_array()
            .unwrap_or_else(|| panic!("server/discover missing supportedVersions: {discover_body:?}"))
            .iter()
            .map(|v| v.as_str().unwrap_or_default().to_string())
            .collect();
        for known in ALL_VERSIONS {
            assert!(
                supported.iter().any(|v| v == known),
                "server/discover must advertise {known}, got {supported:?}"
            );
        }

        let meta = json!({
            "io.modelcontextprotocol/protocolVersion": version,
            "io.modelcontextprotocol/clientCapabilities": {}
        });

        let list = post_json_rpc(
            &client,
            &base,
            json_headers(None, None),
            json!({"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {"_meta": meta}}),
        )
        .await;
        assert_eq!(list.status, reqwest::StatusCode::OK, "tools/list failed: {}", list.raw_text);
        assert_tool_count(&list.body.expect("tools/list produced a JSON-RPC body"));

        let call = post_json_rpc(
            &client,
            &base,
            json_headers(None, None),
            json!({
                "jsonrpc": "2.0", "id": 3, "method": "tools/call",
                "params": {"name": "read_graph", "arguments": {}, "_meta": meta}
            }),
        )
        .await;
        assert_eq!(call.status, reqwest::StatusCode::OK, "tools/call failed: {}", call.raw_text);
        assert_successful_call(&call.body.expect("tools/call produced a JSON-RPC body"));
    } else {
        // First request of a legacy session carries no MCP-Protocol-Version
        // header: the header is validated against the initialize body only
        // when the client chooses to send it.
        let initialize = post_json_rpc(
            &client,
            &base,
            json_headers(None, None),
            json!({
                "jsonrpc": "2.0", "id": 1, "method": "initialize",
                "params": {
                    "protocolVersion": version,
                    "capabilities": {},
                    "clientInfo": {"name": "protocol-matrix-test", "version": "0.0.0"}
                }
            }),
        )
        .await;
        assert_eq!(
            initialize.status,
            reqwest::StatusCode::OK,
            "initialize failed: {}",
            initialize.raw_text
        );
        let session_id = initialize
            .session_id
            .clone()
            .unwrap_or_else(|| panic!("initialize response missing Mcp-Session-Id header"));
        let initialize_body = initialize
            .body
            .unwrap_or_else(|| panic!("initialize produced no JSON-RPC body: {}", initialize.raw_text));
        assert_eq!(
            initialize_body["result"]["protocolVersion"], version,
            "server did not echo the requested legacy protocol version: {initialize_body:?}"
        );

        let initialized = post_json_rpc(
            &client,
            &base,
            json_headers(Some(&session_id), Some(version)),
            json!({"jsonrpc": "2.0", "method": "notifications/initialized"}),
        )
        .await;
        assert_eq!(
            initialized.status,
            reqwest::StatusCode::ACCEPTED,
            "notifications/initialized was not accepted: {}",
            initialized.raw_text
        );

        let list = post_json_rpc(
            &client,
            &base,
            json_headers(Some(&session_id), Some(version)),
            json!({"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}}),
        )
        .await;
        assert_eq!(list.status, reqwest::StatusCode::OK, "tools/list failed: {}", list.raw_text);
        assert_tool_count(&list.body.expect("tools/list produced a JSON-RPC body"));

        let call = post_json_rpc(
            &client,
            &base,
            json_headers(Some(&session_id), Some(version)),
            json!({
                "jsonrpc": "2.0", "id": 3, "method": "tools/call",
                "params": {"name": "read_graph", "arguments": {}}
            }),
        )
        .await;
        assert_eq!(call.status, reqwest::StatusCode::OK, "tools/call failed: {}", call.raw_text);
        assert_successful_call(&call.body.expect("tools/call produced a JSON-RPC body"));
    }
}

#[tokio::test]
async fn http_protocol_version_2024_11_05() {
    run_http_version_case("2024-11-05").await;
}

#[tokio::test]
async fn http_protocol_version_2025_03_26() {
    run_http_version_case("2025-03-26").await;
}

#[tokio::test]
async fn http_protocol_version_2025_06_18() {
    run_http_version_case("2025-06-18").await;
}

#[tokio::test]
async fn http_protocol_version_2025_11_25() {
    run_http_version_case("2025-11-25").await;
}

#[tokio::test]
async fn http_protocol_version_2026_07_28_uses_discover_and_per_request_meta() {
    run_http_version_case("2026-07-28").await;
}

// ─────────────────────────────────────────────────────────────────────────
// HTTP header edge cases explicitly called out in the task.
// ─────────────────────────────────────────────────────────────────────────

async fn establish_http_session(base: &str, client: &Client, version: &str) -> String {
    let initialize = post_json_rpc(
        client,
        base,
        json_headers(None, None),
        json!({
            "jsonrpc": "2.0", "id": 1, "method": "initialize",
            "params": {
                "protocolVersion": version,
                "capabilities": {},
                "clientInfo": {"name": "protocol-matrix-test", "version": "0.0.0"}
            }
        }),
    )
    .await;
    assert_eq!(initialize.status, reqwest::StatusCode::OK, "initialize failed: {}", initialize.raw_text);
    initialize
        .session_id
        .unwrap_or_else(|| panic!("initialize response missing Mcp-Session-Id header"))
}

#[tokio::test]
async fn http_missing_protocol_version_header_defaults_to_legacy() {
    let base = spawn_http_server().await;
    let client = Client::new();
    let session_id = establish_http_session(&base, &client, "2025-03-26").await;

    // No MCP-Protocol-Version header at all on this follow-up request.
    let list = post_json_rpc(
        &client,
        &base,
        json_headers(Some(&session_id), None),
        json!({"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}}),
    )
    .await;
    assert_eq!(
        list.status,
        reqwest::StatusCode::OK,
        "an absent MCP-Protocol-Version header must default to 2025-03-26, not fail: {}",
        list.raw_text
    );
    assert_tool_count(&list.body.expect("tools/list produced a JSON-RPC body"));
}

#[tokio::test]
async fn http_unknown_protocol_version_header_is_rejected() {
    let base = spawn_http_server().await;
    let client = Client::new();
    let session_id = establish_http_session(&base, &client, "2025-03-26").await;

    let list = post_json_rpc(
        &client,
        &base,
        json_headers(Some(&session_id), Some("1999-01-01")),
        json!({"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}}),
    )
    .await;
    assert_eq!(
        list.status,
        reqwest::StatusCode::BAD_REQUEST,
        "an unknown MCP-Protocol-Version header must be rejected with 400: {}",
        list.raw_text
    );
}

#[tokio::test]
async fn http_initialize_with_unknown_newer_version_falls_back_to_newest_supported() {
    let base = spawn_http_server().await;
    let client = Client::new();

    // A version newer than every known revision, and no MCP-Protocol-Version
    // header (which would otherwise have to match the body exactly).
    let initialize = post_json_rpc(
        &client,
        &base,
        json_headers(None, None),
        json!({
            "jsonrpc": "2.0", "id": 1, "method": "initialize",
            "params": {
                "protocolVersion": "2099-01-01",
                "capabilities": {},
                "clientInfo": {"name": "protocol-matrix-test", "version": "0.0.0"}
            }
        }),
    )
    .await;
    assert_eq!(
        initialize.status,
        reqwest::StatusCode::OK,
        "a client requesting an unknown newer version must fall back, not fail: {}",
        initialize.raw_text
    );
    let body = initialize
        .body
        .expect("initialize produced a JSON-RPC body");
    assert_eq!(
        body["result"]["protocolVersion"], "2025-11-25",
        "server must fall back to its newest legacy-handshake version: {body:?}"
    );
}
