//! Connection lanes and embedded-mode admission for `SurrealStorage`.
//!
//! Every storage operation obtains its database handle as a [`DbLease`]. A
//! lease resolves two independent concerns:
//!
//! * **Lane (server mode).** `Surreal<Any>` clones share one WebSocket, so a
//!   heavy write (compression, summarisation, mindmap rewrites, bulk ops)
//!   head-of-line-blocks interactive reads issued through any clone. When the
//!   heavy-write lane is enabled it is an *independently connected and
//!   authenticated* transport with its own `ArcSwap` cell and reconnect
//!   lifecycle. Heavy operations mark their task with [`Sessions::heavy_scope`];
//!   every lease taken inside that scope (including nested storage calls)
//!   resolves to the heavy lane.
//! * **Admission (embedded mode).** RocksDB serialises overlapping
//!   transactions at its lock stripes, so at most `SURREAL_EMBEDDED_MAX_INFLIGHT`
//!   tasks may hold database access at once. The permit wait is bounded by the
//!   operation deadline. Admission is reentrant per Tokio task: a storage call
//!   made while the same task already holds a lease reuses that permit, so a
//!   nested call (e.g. `add_memory` → `search_memories`) can never wait on a
//!   permit its own caller holds.
//!
//! The per-task registry is a `std::sync::Mutex` held only for map updates —
//! never across an `.await` (`clippy::await_holding_lock` is denied).

use super::surreal::ConnectionCell;
use anyhow::{Context, Result};
use arc_swap::ArcSwap;
use std::collections::HashMap;
use std::ops::Deref;
use std::sync::{Arc, Mutex, MutexGuard, PoisonError};
use std::time::Duration;
use surrealdb::{Surreal, engine::any::Any};
use tokio::sync::{OwnedSemaphorePermit, Semaphore};
use tokio::task::Id as TaskId;

/// Which server-mode connection a lease runs on.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum Lane {
    /// Reads and short writes. Always present; in embedded mode or with a
    /// single server lane this is the only connection.
    Interactive,
    /// Heavy writes, on an independently connected transport.
    Heavy,
}

#[derive(Default)]
struct TaskSlot {
    /// Live leases held by this task that carry the admission permit.
    leases: usize,
    permit: Option<OwnedSemaphorePermit>,
    /// Nesting depth of `heavy_scope` guards alive in this task.
    heavy_depth: usize,
}

/// Connection cells plus embedded admission control for one storage instance.
pub(crate) struct Sessions {
    interactive: Arc<ArcSwap<ConnectionCell>>,
    heavy: Option<Arc<ArcSwap<ConnectionCell>>>,
    admission: Option<Arc<Semaphore>>,
    tasks: Mutex<HashMap<TaskId, TaskSlot>>,
}

impl Sessions {
    pub(crate) fn new(
        interactive: Surreal<Any>,
        heavy: Option<Surreal<Any>>,
        admission_permits: Option<usize>,
    ) -> Self {
        let cell = |db| Arc::new(ArcSwap::new(Arc::new(ConnectionCell::Connected(db))));
        Self {
            interactive: cell(interactive),
            heavy: heavy.map(cell),
            admission: admission_permits.map(|n| Arc::new(Semaphore::new(n))),
            tasks: Mutex::new(HashMap::new()),
        }
    }

    /// Build from explicit cells (tests that need non-connected states).
    #[cfg(test)]
    pub(crate) fn from_cells(
        interactive: ConnectionCell,
        heavy: Option<ConnectionCell>,
        admission_permits: Option<usize>,
    ) -> Self {
        let cell = |state| Arc::new(ArcSwap::new(Arc::new(state)));
        Self {
            interactive: cell(interactive),
            heavy: heavy.map(cell),
            admission: admission_permits.map(|n| Arc::new(Semaphore::new(n))),
            tasks: Mutex::new(HashMap::new()),
        }
    }

    /// Number of tasks currently holding an admission permit.
    #[cfg(test)]
    pub(crate) fn admitted_tasks(&self) -> usize {
        self.lock_tasks()
            .values()
            .filter(|slot| slot.permit.is_some())
            .count()
    }

    /// The `ArcSwap` cell backing a lane. `Heavy` falls back to the
    /// interactive cell when no heavy lane is configured.
    pub(crate) fn cell(&self, lane: Lane) -> &Arc<ArcSwap<ConnectionCell>> {
        match (lane, &self.heavy) {
            (Lane::Heavy, Some(heavy)) => heavy,
            _ => &self.interactive,
        }
    }

    /// Unmetered handle for a lane: one atomic load, no admission. Used for
    /// probes and for handing a raw handle to external callers.
    pub(crate) fn live(&self, lane: Lane) -> Result<Surreal<Any>> {
        let cell = self.cell(lane).load();
        match &**cell {
            ConnectionCell::Connected(db) => Ok(db.clone()),
            ConnectionCell::Reconnecting => {
                anyhow::bail!("Connection is currently reconnecting, please retry later")
            }
            ConnectionCell::Failed(msg) => anyhow::bail!("Connection failed: {}", msg),
        }
    }

    fn lock_tasks(&self) -> MutexGuard<'_, HashMap<TaskId, TaskSlot>> {
        // The map holds only counters and permits; a panic mid-update cannot
        // leave it in a state worth refusing service over.
        self.tasks.lock().unwrap_or_else(PoisonError::into_inner)
    }

    /// Whether the per-task registry has anything to track.
    fn tracks_tasks(&self) -> bool {
        self.admission.is_some() || self.heavy.is_some()
    }

    fn current_lane(&self, task: Option<TaskId>) -> Lane {
        match (task, self.heavy.is_some()) {
            (Some(id), true) => {
                let tasks = self.lock_tasks();
                match tasks.get(&id) {
                    Some(slot) if slot.heavy_depth > 0 => Lane::Heavy,
                    _ => Lane::Interactive,
                }
            }
            _ => Lane::Interactive,
        }
    }

    /// Route every lease taken by the current task to the heavy-write lane
    /// until the returned guard drops. No-op without a heavy lane or outside
    /// a Tokio task.
    pub(crate) fn heavy_scope(self: &Arc<Self>) -> HeavyScope {
        let task = if self.heavy.is_some() {
            tokio::task::try_id()
        } else {
            None
        };
        if let Some(id) = task {
            self.lock_tasks().entry(id).or_default().heavy_depth += 1;
        }
        HeavyScope {
            sessions: task.map(|id| (Arc::clone(self), id)),
        }
    }

    /// Obtain a database handle for one storage operation. In embedded mode
    /// this waits (bounded by `deadline`) for an admission permit unless the
    /// current task already holds one.
    pub(crate) async fn lease(self: &Arc<Self>, deadline: Duration) -> Result<DbLease> {
        let task = if self.tracks_tasks() {
            tokio::task::try_id()
        } else {
            None
        };
        let lane = self.current_lane(task);
        let admission = match &self.admission {
            Some(semaphore) => Some(self.admit(semaphore, task, deadline).await?),
            None => None,
        };
        let db = self.live(lane)?;
        Ok(DbLease {
            db,
            lane,
            _admission: admission,
        })
    }

    async fn admit(
        self: &Arc<Self>,
        semaphore: &Arc<Semaphore>,
        task: Option<TaskId>,
        deadline: Duration,
    ) -> Result<Admission> {
        if let Some(id) = task {
            let mut tasks = self.lock_tasks();
            if let Some(slot) = tasks.get_mut(&id)
                && slot.leases > 0
            {
                slot.leases += 1;
                return Ok(Admission::Task {
                    sessions: Arc::clone(self),
                    task: id,
                });
            }
        }

        let permit = tokio::time::timeout(deadline, Arc::clone(semaphore).acquire_owned())
            .await
            .map_err(|_| {
                anyhow::anyhow!(
                    "Embedded admission wait exceeded the {}ms operation deadline \
                     (SURREAL_EMBEDDED_MAX_INFLIGHT permits all in use)",
                    deadline.as_millis()
                )
            })?
            .context("embedded concurrency semaphore was closed")?;

        let Some(id) = task else {
            return Ok(Admission::Owned { _permit: permit });
        };
        let surplus = {
            let mut tasks = self.lock_tasks();
            let slot = tasks.entry(id).or_default();
            slot.leases += 1;
            // A concurrent branch of this same task (e.g. inside `join!`) may
            // have been admitted while we waited; keep one permit per task.
            match slot.permit {
                Some(_) => Some(permit),
                None => {
                    slot.permit = Some(permit);
                    None
                }
            }
        };
        drop(surplus);
        Ok(Admission::Task {
            sessions: Arc::clone(self),
            task: id,
        })
    }

    fn release_task_lease(&self, id: TaskId) {
        let released = {
            let mut tasks = self.lock_tasks();
            let Some(slot) = tasks.get_mut(&id) else {
                return;
            };
            slot.leases = slot.leases.saturating_sub(1);
            if slot.leases > 0 {
                return;
            }
            let permit = slot.permit.take();
            if slot.heavy_depth == 0 {
                tasks.remove(&id);
            }
            permit
        };
        drop(released);
    }

    fn exit_heavy_scope(&self, id: TaskId) {
        let mut tasks = self.lock_tasks();
        if let Some(slot) = tasks.get_mut(&id) {
            slot.heavy_depth = slot.heavy_depth.saturating_sub(1);
            if slot.heavy_depth == 0 && slot.leases == 0 {
                tasks.remove(&id);
            }
        }
    }
}

/// Embedded admission held by a lease.
enum Admission {
    /// Outside a Tokio task: the lease owns its permit directly.
    Owned { _permit: OwnedSemaphorePermit },
    /// The permit is shared by every lease of this task.
    Task { sessions: Arc<Sessions>, task: TaskId },
}

impl Drop for Admission {
    fn drop(&mut self) {
        if let Admission::Task { sessions, task } = self {
            sessions.release_task_lease(*task);
        }
    }
}

/// A database handle valid for one storage operation. Dereferences to
/// `Surreal<Any>`; dropping it releases the embedded admission permit (if
/// this was the task's last live lease).
pub(crate) struct DbLease {
    db: Surreal<Any>,
    lane: Lane,
    _admission: Option<Admission>,
}

impl DbLease {
    /// A lease with no admission accounting (palace adapters built from a
    /// caller-supplied closure).
    #[cfg(feature = "palace")]
    pub(crate) fn unmetered(db: Surreal<Any>) -> Self {
        Self {
            db,
            lane: Lane::Interactive,
            _admission: None,
        }
    }

    pub(crate) fn lane(&self) -> Lane {
        self.lane
    }
}

impl Deref for DbLease {
    type Target = Surreal<Any>;

    fn deref(&self) -> &Surreal<Any> {
        &self.db
    }
}

/// Guard returned by [`Sessions::heavy_scope`].
pub(crate) struct HeavyScope {
    sessions: Option<(Arc<Sessions>, TaskId)>,
}

impl Drop for HeavyScope {
    fn drop(&mut self) {
        if let Some((sessions, id)) = self.sessions.take() {
            sessions.exit_heavy_scope(id);
        }
    }
}

/// Typed, read-only view of a storage instance's connections, handed to the
/// palace adapter in place of the raw `ArcSwap` cell. It can take leases
/// (resilient to reconnection, subject to admission and lanes) but cannot
/// publish connection state.
#[cfg(feature = "palace")]
#[derive(Clone)]
pub(crate) struct ConnectionView {
    sessions: Arc<Sessions>,
    deadline: Duration,
}

#[cfg(feature = "palace")]
impl ConnectionView {
    pub(crate) fn new(sessions: Arc<Sessions>, deadline: Duration) -> Self {
        Self { sessions, deadline }
    }

    pub(crate) async fn lease(&self) -> Result<DbLease> {
        self.sessions.lease(self.deadline).await
    }
}
